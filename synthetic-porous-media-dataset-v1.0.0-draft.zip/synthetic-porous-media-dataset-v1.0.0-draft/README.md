# Synthetic Porous Media Image Dataset

Author: Fengrui Wang  
Version: v1.0.0 (local draft)  
Prepared: 2026-11-08  
License: Not selected. This local draft does not grant an open-data reuse license.

This dataset contains 2,000 two-dimensional synthetic porous-medium binary
images paired with COMSOL-derived permeability labels for left-to-right flow.
The images describe synthetic structures, not measured three-dimensional rocks.

## Contents

- `images/`: 2,000 lossless grayscale PNG files.
- `labels.csv`: one row per image, including its relative file path, geometry
  family, porosity and permeability.
- `README.md`: data definitions and a loading example.

The full image archive can be distributed as a GitHub Release attachment.
Extract the ZIP before using the example below. All paths in the CSV are
relative to the extracted dataset directory.

## Structure families

| Method | Description | Images |
|---|---|---:|
| `circle` | Circular solid-particle structures | 300 |
| `voronoi` | Voronoi-derived pore-channel structures | 500 |
| `curved_voronoi` | Curved Voronoi-derived particle structures | 1,200 |

## Image encoding and physical scale

- Resolution: 400 rows by 400 columns; unsigned 8-bit grayscale.
- White (`255`): pore/fluid space. Black (`0`): solid.
- Physical domain: 1 mm by 1 mm for every image.
- Pixel spacing: 2.5 micrometres by 2.5 micrometres.
- PNG pixels equal the source binary array multiplied by 255. There is no
  resizing, interpolation, rotation, transpose or row flip.
- Source array indexing is preserved as `[row, column]`. For a Cartesian plot
  with the vertical coordinate increasing upwards, use `origin="lower"`.
- Porosity is the number of white pixels divided by 160,000.

## Label definitions

| Column | Meaning | Unit / values |
|---|---|---|
| `sample_id` | Unique sample identifier; also the image basename | Text |
| `image_file` | Relative path to the image | `images/<sample_id>.png` |
| `method` | Synthetic structure family | The three method names above |
| `porosity` | Pore-pixel fraction | Dimensionless; between 0 and 1 |
| `permeability_k` | COMSOL-derived left-to-right permeability | m^2 |
| `log10_permeability_k` | Base-10 logarithm of the numeric k value in m^2 | log10(k / 1 m^2) |

Permeability labels originate from steady-state, two-dimensional creeping-flow
simulations on the corresponding continuous geometries. They were computed
using the project's Darcy-law outlet-flow expression. The PNGs are rasterized
representations of those geometries; recomputing flow directly on the pixel
grid need not reproduce the continuous-geometry labels exactly.

The label values and sample order are preserved from the cleaned source table.
Only the two identifying columns `image_file` and `method` have been added.
The sample IDs select the 2,000 images in the current cleaned labels and
metadata; other local images are outside this release candidate.

The complete retained set has porosity from
0.15155625 to
0.4494875, and permeability from
6.5000559e-14 to
2.4066553e-11 m^2.

## Loading one sample

Install NumPy and Pillow, then run this from the extracted dataset directory:

```python
import csv
from pathlib import Path

import numpy as np
from PIL import Image

root = Path(".")
with (root / "labels.csv").open(encoding="utf-8", newline="") as stream:
    row = next(csv.DictReader(stream))

with Image.open(root / row["image_file"]) as image:
    pore_mask = (np.asarray(image) == 255).astype(np.uint8)

print(row["sample_id"], pore_mask.shape)
print("Porosity:", pore_mask.mean())
print("Permeability (m^2):", float(row["permeability_k"]))
```

## Release scope

This minimal image/label dataset supports structure analysis and supervised
permeability prediction. The package does not include continuous geometries,
pressure/velocity fields, solver models, trained networks or the paper's fixed
train/validation/test split. Reproducing the paper's exact numerical benchmark
requires its split and model configuration in addition to this dataset.

## Authorship, license and citation

Dataset author: Fengrui Wang.

The data owner has intentionally deferred the license decision. This archive is
a local draft; the license must be selected and documented before an open-data
release. No license text or public DOI has been assigned to this draft.

Before publication, update the version/date and add the final repository URL,
license and preferred citation. A public repository URL or DOI should only be
added after it has been assigned.

## 中文说明

作者：Fengrui Wang。本地草稿包含 2,000 张 400×400 的二维合成多孔介质图像及对应标签。
白色（255）为孔隙，黑色（0）为固体；每张图对应 1 mm×1 mm，像素间距为 2.5 μm。
`permeability_k` 的单位为 m²，`porosity` 为孔隙像素比例。
本草稿尚未选定数据使用许可，公开发布前需补齐许可和正式引用信息。
